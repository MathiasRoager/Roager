using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Weapon : MonoBehaviour
{
    public string weaponName;
    public float speedReduction;
    public bool isReloading; // Flag to indicate if the weapon is currently reloading
    public float nextFireTime; // The next time the weapon can be fired
    public Weapon(string weaponName){
        this.weaponName = weaponName;
    }

    public abstract void Shoot();

    public virtual IEnumerator Reload()
    {
        yield return new WaitForSeconds(0);
    }
}

