using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon3 : Weapon
{
    public Weapon3():base("Machete"){

    }
    private void Awake() {
        speedReduction = 15f;
    }
    public override void Shoot(){}
}
