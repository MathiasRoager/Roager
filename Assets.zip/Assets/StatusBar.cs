using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StatusBar : MonoBehaviour
{
   [SerializeField] Transform bar;

   public void Setstate(int current, int max ) 
   {
        float state = (float)current;
        state /= max;
        if (state < 0.7f) {state = 0.7f;}
        bar.localScale = new Vector3(state, 1f, 1f); 
   }
}
