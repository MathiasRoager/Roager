using System.Collections.Generic;

public class weaponSlots {
    private int currentWeaponIndex; // index of the current weapon

    public int numWeaponSlots;
    List<Weapon> weaponList = new List<Weapon>(){
        null, null, null, null
    };

    public weaponSlots(int _numWeaponSlots) {
        numWeaponSlots = _numWeaponSlots;
        currentWeaponIndex = 0; // set the current weapon index to the first slot
    }
    public void AddWeapon(Weapon weapon, int slot){
        if(slot >= 0 && slot < weaponList.Capacity) {
            weaponList.Insert(slot,weapon);
        }
    }

    public void SwitchToWeapon(int slot) {
        if (slot >= 0 && slot < weaponList.Capacity) {
            currentWeaponIndex = slot; // set the current weapon index to the specified slot
        }
    }

    public Weapon GetCurrentWeapon() {
        return weaponList[currentWeaponIndex]; // return the weapon in the current slot
    }
}


