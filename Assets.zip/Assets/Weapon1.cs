using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon1 : Weapon
{
    public Weapon1():base("Pistol"){

    }
    private void Awake() {
        speedReduction = 5f;
    }

    public int magazineSize = 12; // The number of bullets that can be fired before reloading
    public float reloadSpeed = 2.0f; // The time it takes to reload the weapon
    public float fireRate = 0.34f; // The time between shots fired
    public float reducedspeed = 0.95f; //The movementspeed is therefore reduced to 0,95%
    public float reloadwalkspeed = 0.65f; //Walk speed when reloading. 
    private int currentAmmo; // The number of bullets currently in the magazine
    public GameObject Bullet1;
    void Start()
    {
        currentAmmo = magazineSize; // Set the initial ammo count to the magazine size
    }

    

    public override void Shoot()
    {
        // Subtract one from the current ammo count
        currentAmmo--;

        // Set the next fire time based on the fire rate
        nextFireTime = Time.time + fireRate;

        // Fire a bullet
        GameObject temporary = Instantiate(Bullet1, transform.position, Quaternion.identity);
        print("bang");
        temporary.GetComponent<Rigidbody>().AddForce(transform.forward*2f, ForceMode.Impulse);
    }

    public override IEnumerator Reload()
    {
        // Set the reloading flag to true
        isReloading = true;

        // Wait for the reload speed before adding ammo back to the magazine
        yield return new WaitForSeconds(reloadSpeed);

        // Add ammo back to the magazine up to the magazine size
        currentAmmo = Mathf.Min(currentAmmo + (magazineSize - currentAmmo), magazineSize);

        // Reset the reloading flag
        isReloading = false;
    }
}
