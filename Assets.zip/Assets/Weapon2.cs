using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon2 : Weapon
{
    public Weapon2():base("Shotgun"){

    }
    private void Awake() {
        speedReduction = 10f;
    }

    public override void Shoot(){}
}
