using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class character : MonoBehaviour
{
    // Start is called before the first frame update
    // Componets
    public Rigidbody2D rb = null;
    private Weapon weapon;

    // Player
    public float walkSpeed = 4f;
    float speedLimiter = 0.7f;
    float inputHorizontal = 0f;
    float inputVertical = 0f;
    weaponSlots characterWeapons;

    public int amountOfSlots = 4;


    public void Start(){
        // rb = gameObject.GetComponent<Rigidbody2D>();
        characterWeapons = new weaponSlots(amountOfSlots);
        // Create a group of vampire survivors with 4 weapon slots

        // Add a pistol to the first slot
        Weapon1 pistol = new Weapon1();
        characterWeapons.AddWeapon(pistol, 0);

        // Add a shotgun to the second slot
        Weapon2 shotgun = new Weapon2();
        characterWeapons.AddWeapon(shotgun, 1);

        // Add a machete to the third slot
        Weapon3 machete = new Weapon3();
        characterWeapons.AddWeapon(machete, 2);

        // Add a machete to the third slot
        Weapon4 machinegun = new Weapon4();
        characterWeapons.AddWeapon(machinegun, 3);

        // Switch to the shotgun
        characterWeapons.SwitchToWeapon(0);

        // Use the current weapon
        weapon = characterWeapons.GetCurrentWeapon();
    }

    // Update is called once per frame
    void Update()
    {
        inputHorizontal = Input.GetAxis("Horizontal");
        inputVertical = Input.GetAxis("Vertical");
        Playeranimation();
        // If the weapon is reloading, exit early
        if ( true || Time.time >= weapon.nextFireTime)
        {
            weapon.Shoot();
        }
        if (weapon.isReloading)
        {
            return;
        }

        // If the fire button is pressed and the weapon can fire again, shoot a bullet
        //Input.GetButton("Fire1") &&
        

        // If the reload button is pressed and the weapon isn't already reloading, start the reload process
        // if (Input.GetButtonDown("Reload") && !weapon.isReloading)
        // {
        //     StartCoroutine(weapon.Reload());
        // }
    }

    void FixedUpdate()
    {
        rb.MovePosition(
            rb.position + new Vector2(inputHorizontal, inputVertical).normalized * (walkSpeed * (1f - (weapon.speedReduction/100))) * Time.fixedDeltaTime
        );
        if (timer > 60f * 5)
        {
            timer = 0f;
        }
        else
        {
            timer += Time.fixedDeltaTime;
        }
    }

    public static float timer = 0;

    [SerializeField]
    int health;

    [SerializeField]
    int maxHealth;


    public int GetHealth()
    {
        return health;
    }

    public float GetHealthPercent()
    {
        return (float)health / maxHealth;
    }

    public void Damage(int amount)
    {
        health -= amount;
        if (health < 0)
        {
            health = 0;
        }
    }

    [SerializeField] StatusBar hpbar;
    public void Heal(int amount)
    {
        health += amount;
        if (health > maxHealth)
        {
            health = maxHealth;
        }
        hpbar.Setstate(health, maxHealth);
    }
   
    void Playeranimation()
    {
        //if st
        //if chopping wood play lumbering animation  
        // if (Input.GetMouseButtonDown(0))
        // {
        //     GetComponentInChildren<Animation>().Play("Lumbering");
        // }
       
        // //if moving play walking animation
        // if (Input.GetAxis("Horizontal") != 0 || Input.GetAxis("Vertical") != 0)
        // {
        //     GetComponentInChildren<Animation>().Play("Walk");
        // }

    }
    
}
