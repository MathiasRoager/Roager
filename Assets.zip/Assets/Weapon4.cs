using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon4 : Weapon
{
    public Weapon4():base("Machine gun"){

    }
    private void Awake() {
        speedReduction = 35f;
    }
    public override void Shoot(){}
}
